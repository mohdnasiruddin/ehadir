<?php 

include 'top.php'; 

if(($_SESSION['level'])!="0"){
  header("Location: login.php");
}

?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

<?php include 'sidebar.php'; ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

<?php include 'topbar.php'; ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">


          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Laporan e-Kehadiran KVDSAZI</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th align="center">Bil</th>
                      <th>Nama</th>
                      <th align="center">Tarikh</th>
                      <th align="center">Masa</th>
                      <th align="center">Suhu</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php 

                  $thn = $_SESSION['tahun'];
                  $cls = $_SESSION['kelas'];
                      $data3 = mysqli_query($connection,"SELECT * FROM studInfo WHERE stud_year='$thn' AND stud_class='$cls'");
//                      $data3 = mysqli_query($connection,"SELECT  studinfo.*, hadirinfo.* from studinfo INNER JOIN hadirinfo INNER JOIN userinfo ON studinfo.stud_id = hadirinfo.stud_id WHERE studinfo.stud_year = userinfo.user_year AND studinfo.stud_class = userinfo.user_class ");

                      $no = 1;
                      while ($info3=mysqli_fetch_array($data3)) 
                      {

                      
                   ?>
                  
                    <tr>
                      <td align="center"><?php echo $no; ?></td>
                      <td><?php echo $info3['stud_name']; ?></td>

                      <?php 
                        $idPel = $info3['stud_id'];
                        //$tarikh = date("Y-m-d");

                        $data4 = mysqli_query($connection, "SELECT * FROM hadirInfo WHERE stud_id = '$idPel' AND hadir_date='2020-06-26' ");

                        if(mysqli_num_rows($data4) == 0){ ?>

                          <td align="center" colspan="3" class="bg-gradient-danger text-white">
                           TIADA DATA
                          </td>

                        <?php
                        } else {

                        while ($info4=mysqli_fetch_array($data4)) {
                      ?>
                      <td align="center"><?php echo $info4['hadir_date']; ?></td>
                      <td align="center"><?php echo $info4['hadir_time']; ?></td>
                      <td align="center"><?php echo $info4['hadir_suhu']; ?></td>
                    <?php } }?>

                    </tr>
                    
                  
                <?php 
                $no++;
              } ?></tbody>
                </table>
                
              </div><br><br><br>
                  <a href="report.php?thn=<?php echo $thn ;?>&kls=<?php echo $cls ;?>&tarikh=2020-06-26" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Cetak</span>
                  </a>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

<?php include 'footer.php'; ?>
</body>

</html>
